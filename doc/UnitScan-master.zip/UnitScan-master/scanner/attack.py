#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

from file.auxtext import AuxText
#from mod_xss import mod_xss

#from mod_xss import Attack_XSS