from scrapy.spider import BaseSpider

class Spider0(BaseSpider):
    allowed_domains = ["scrapy1.org", "scrapy3.org"]
