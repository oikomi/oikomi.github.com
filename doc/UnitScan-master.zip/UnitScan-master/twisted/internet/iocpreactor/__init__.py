# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
I/O Completion Ports reactor
"""

from twisted.internet.iocpreactor.reactor import install

__all__ = ['install']
