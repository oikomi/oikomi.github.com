
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Cred

Support for verifying credentials, and providing services to users based on
those credentials.

(This package was previously known as the module twisted.internet.passport.)
"""
