---
layout: page
title: "Messages"
tagline: ""
description: ""
group: "navigation"
---
{% include JB/setup %}
#### 这里就是一块留言板，有什么想说的、想问的、想写的，都放这里吧。。
#### Just a message board, whatever you wanna say, ask, write, put here..

---
{% include JB/comments %}
