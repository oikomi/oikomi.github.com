---
layout: page
title: "About"
tagline: ""
description: ""
group: "navigation"
---
{% include JB/setup %}

### 关于我

未出师程序员一枚，在校大学生一个  
熟悉C语言，会用C++，能写Java，略懂Python

#### 我的网名？
网名喜欢用Ever，但是这个4个字母的短词经常是被注册了，抑或是太短。。。所以用过几次everax，所以邮箱和csdn帐号就是everax了，但是又觉得这个不那么好看。。。。而且加的ax没有意义，之后就用了iEverX，虽然i和X其实还是没有意义，不过看着好多了。。之前的东西没法改名字的就没改过来，小郁闷

### 关于网站

在这个网站，我会记录一些自己在编程时的一些思想、感悟、体会，分享自己编程的点点滴滴，也算是自己编程之路的一个个脚印吧。同时，可能还会有一些自己翻译的文章（当然英文不好，这个就是暂时放在这里）。此外，也可能会有一些自己的生活杂记。

#### 技术

* 网站源码：<https://github.com/iEverX/ieverx.github.com>
* [Jekyll Bootstrap][]
* [Twitter Bootstrap][]
* [jQuery][]

### 联系我？

我的邮箱：g.everax(at)gmail.com，有时查的很勤，有时就少看  
新浪微博: [iEverX][weibo]，有事没事就去逛逛  
github：[iEverX][github]，我的一些代码可以在这里找到  

[weibo]: http://weibo.com/ieverx
[github]: http://github.com/iEverX
[Jekyll Bootstrap]: http://jekyllbootstrap.com "The Definitive Jekyll Blogging Framework"
[Twitter Bootstrap]: http://twitter.github.com/bootstrap/
[jQuery]: http://jquery.com
