# EverCoding.net

A static blog built with [Jekyll-BootStrap][] on github pages

**EverCoding.net** is my domain.

## Function that has been realized

* Home page shows rencent post, categories and tags
* Home page pagination and go to top of page
* RSS subscribe and site search, with source code from [Skydark's blog][]
* Sina Weibo pay-attention button
* Abstract of posts in home page
* Declaration at end of each post
* Friend Links
* Code hightlight with google-code-prettify
* Archive and Tags page selection show
* My personal theme: black
* Button clicking to show comments

## Function that will be realized

* The post with most comments
* The latest comments
* Any others


---

With this blog, I will write something about programming, programmers and some of my life  
I hope I would not give up updating this blog

**Always not be fickle in a fickle society!**  
**Having Dream, Heart Live**

[Jekyll-BootStrap]: http://jekyllbootstrap.com
[Skydark's blog]: http://blog.skydark.info
